import { useState, useCallback, useRef } from "react";
import Toast from "./components/Toast";
import {
  samples,
  userContext,
  fallbackUploadPlan,
  normalizeVision,
  normalizePlan,
} from "./data/samples";

function makeUploadSample(vision, plan) {
  const v = normalizeVision(vision);
  const itemNames = v.items.slice(0, 6).map((item) => item.name);
  return {
    id: "upload",
    name: "现场上传",
    scene: "上传图片待识别",
    fridge: {
      shelfTop: itemNames.slice(0, 3),
      shelfMid: itemNames.slice(3, 6),
      shelfLow: ["待确认", "安全边界"],
    },
    vision: v,
    plan: normalizePlan(plan),
  };
}

async function postJson(url, payload) {
  const resp = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    throw new Error(data.detail || data.error || `request failed: ${resp.status}`);
  }
  return data;
}

const ICON_MAP = {
  quick: { bg: "#e8f5e9", color: "#2f6f5e" },
  practice: { bg: "#e3f2fd", color: "#1976d2" },
  late: { bg: "#fbe9e7", color: "#e64a19" },
};

export default function App() {
  const [activeSample, setActiveSample] = useState(null);
  const [activeProvider, setActiveProvider] = useState("mock");
  const [uploadedImageDataUrl, setUploadedImageDataUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState("");
  const [toastMessage, setToastMessage] = useState("");
  const [showRecipe, setShowRecipe] = useState(false);
  const fileRef = useRef(null);

  const plan = activeSample?.plan;

  const showToast = useCallback((msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 1600);
  }, []);

  function handleFileChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setUploadedImageDataUrl(reader.result);
    reader.readAsDataURL(file);
  }

  function handleSelectSample(sample) {
    setActiveSample(sample);
    setActiveProvider("mock");
    setUploadedImageDataUrl("");
    setShowRecipe(true);
  }

  async function runAnalysis() {
    if (!uploadedImageDataUrl) {
      showToast("请先上传冰箱照片");
      return;
    }
    setLoading(true);
    setLoadingMsg("AI 正在识别冰箱食材...");

    try {
      const data = await postJson("/api/analyze-fridge", { imageDataUrl: uploadedImageDataUrl });
      setActiveProvider(data.provider || "openai");
      const vision = normalizeVision(data.vision);
      const sample = makeUploadSample(vision, fallbackUploadPlan);
      setActiveSample(sample);
      setLoadingMsg("正在生成晚餐方案...");

      const inventory = vision.items;
      const planData = await postJson("/api/plan-dinner", { inventory, userContext });
      setActiveProvider(planData.provider || "openai");
      setActiveSample((prev) => ({ ...prev, plan: normalizePlan(planData.plan) }));
      setShowRecipe(true);
      showToast("晚餐方案已生成");
    } catch (err) {
      const fallback = makeUploadSample(
        { items: [], uncertainItems: [], warnings: [] },
        fallbackUploadPlan
      );
      setActiveSample(fallback);
      setActiveProvider("mock");
      setShowRecipe(true);
      showToast(err.message || "识别失败，已使用缓存数据");
    } finally {
      setLoading(false);
      setLoadingMsg("");
    }
  }

  function reset() {
    setActiveSample(null);
    setShowRecipe(false);
    setUploadedImageDataUrl("");
    setActiveProvider("mock");
    if (fileRef.current) fileRef.current.value = "";
  }

  // ---- Render: Recipe Card Overlay ----
  const showOverlay = showRecipe && activeSample && plan;

  return (
    <div className="app-shell">
      {/* Status bar - minimal */}
      <div className="top-bar">
        <span className="top-bar-title">冰箱晚餐助手</span>
        {activeProvider !== "mock" && (
          <span className="top-bar-badge">AI</span>
        )}
      </div>

      {/* Upload area - full screen photo zone */}
      <div className="camera-zone">
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          style={{ display: "none" }}
        />
        {uploadedImageDataUrl ? (
          <div className="photo-preview" onClick={() => fileRef.current?.click()}>
            <img src={uploadedImageDataUrl} alt="" />
            <div className="photo-mask">
              <span className="photo-hint">点击更换照片</span>
            </div>
          </div>
        ) : (
          <div className="camera-placeholder" onClick={() => fileRef.current?.click()}>
            <div className="camera-lens">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
                <circle cx="12" cy="13" r="4" />
              </svg>
            </div>
            <p className="camera-label">拍一下今晚的冰箱</p>
            <p className="camera-sub">AI 识别食材 · 智能推荐晚餐</p>
          </div>
        )}
      </div>

      {/* Bottom action bar */}
      <div className="action-bar">
        <button className="btn primary" disabled={!uploadedImageDataUrl || loading} onClick={runAnalysis}>
          {loading ? (
            <>
              <span className="btn-spinner" />
              {loadingMsg}
            </>
          ) : (
            "开始识别"
          )}
        </button>
        <div className="action-row">
          {samples.map((s) => (
            <button
              key={s.id}
              className="quick-sample"
              disabled={loading}
              onClick={() => handleSelectSample(s)}
            >
              <span className="qs-dot" style={{ background: (ICON_MAP[s.id] || ICON_MAP.quick).bg, color: (ICON_MAP[s.id] || ICON_MAP.quick).color }}>
                {s.name[0]}
              </span>
              <span>{s.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Recipe Card Overlay */}
      {showOverlay && (
        <div className="overlay" onClick={(e) => { if (e.target === e.currentTarget) reset(); }}>
          <div className="recipe-card">
            <button className="close-btn" onClick={reset}>&times;</button>

            {/* Header: dish name + score */}
            <div className="recipe-card-header">
              <div className="info">
                <h2>{plan.baseMeal.name}</h2>
                <p className="subtitle">{plan.summary}</p>
                <div className="tags">
                  <span className="tag green">晚餐优选</span>
                  <span className="tag orange">{plan.baseMeal.difficulty}</span>
                  {plan.decision === "quick_meal_first" && (
                    <span className="tag blue">速食优先</span>
                  )}
                </div>
              </div>
              <div className="score-badge">
                <span className="num">{plan.score}</span>
                <span className="unit">推荐</span>
              </div>
            </div>

            {/* Ingredient table */}
            <div className="card-section">
              <h3>食材清单</h3>
              <table className="ingredient-table">
                <thead>
                  <tr>
                    <th>食材</th><th>用量</th><th>状态</th><th>备注</th>
                  </tr>
                </thead>
                <tbody>
                  {(activeSample.vision.items.length > 0
                    ? activeSample.vision.items
                    : plan.baseMeal.requiredItems.map((name) => ({ name, quantityEstimate: "-", state: "待确认", notes: "核心材料", confidence: 1 }))
                  ).map((item, i) => (
                    <tr key={i}>
                      <td><strong>{item.name}</strong></td>
                      <td>{item.quantityEstimate || "-"}</td>
                      <td style={{ color: item.state?.includes("确认") ? "var(--orange)" : "var(--green)" }}>
                        {item.state || "看起来可用"}
                      </td>
                      <td>{item.notes || "-"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Cooking steps */}
            <div className="card-section">
              <h3>烹饪步骤</h3>
              <ol className="step-list">
                {plan.baseMeal.steps.map((step, i) => (
                  <li key={i}>
                    <span className="step-num">{i + 1}</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Stretch meal */}
            {plan.stretchMeal.name && (
              <div className="card-section">
                <h3>进阶方案</h3>
                <div className="sub-card">
                  <div className="sub-name">{plan.stretchMeal.name}</div>
                  <div className="sub-meta">
                    {plan.stretchMeal.why} · {plan.stretchMeal.timeCost} · {plan.stretchMeal.extraSkill}
                  </div>
                </div>
              </div>
            )}

            {/* Shopping upgrade */}
            <div className="card-section">
              <h3>缺料补买</h3>
              <div className="shop-list">
                {plan.shoppingUpgrade.neededItems.filter((i) => i !== "无").map((item, i) => (
                  <span key={i} className="shop-tag">{item}</span>
                ))}
                {plan.shoppingUpgrade.neededItems.filter((i) => i !== "无").length === 0 && (
                  <span className="shop-tag" style={{ background: "#eee", color: "#999" }}>无需补买</span>
                )}
              </div>
              <p className="shop-reason">
                {plan.shoppingUpgrade.reason} · 约 {plan.shoppingUpgrade.estimatedCost}
              </p>
            </div>

            {/* Footer: safety + reason */}
            <div className="recipe-footer">
              <div className="ft-card safety">
                <h4>安全提醒</h4>
                {plan.baseMeal.safetyTips.map((tip, i) => (
                  <div key={i}>· {tip}</div>
                ))}
              </div>
              <div className="ft-card reason">
                <h4>推荐理由</h4>
                {plan.baseMeal.why}
              </div>
            </div>

            {/* Fallback */}
            {plan.fallback.condition && (
              <div className="card-section">
                <h3>兜底方案</h3>
                <div className="sub-card">
                  <div><strong>{plan.fallback.condition}</strong></div>
                  <div className="sub-meta">{plan.fallback.suggestion}</div>
                </div>
              </div>
            )}

            <button className="reset-link" onClick={reset}>
              返回重新拍摄
            </button>
          </div>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="loading-overlay" style={{ position: "fixed", borderRadius: 0 }}>
          <div className="spinner" />
          <p>{loadingMsg}</p>
        </div>
      )}

      <Toast message={toastMessage} />
    </div>
  );
}
